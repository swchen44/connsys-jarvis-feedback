---
name: Edge TTS adelay offset
description: Edge TTS 語音和字幕同步需要 -600ms adelay 偏移補償
type: feedback
originSessionId: d99bf67c-1aff-4667-8f66-0c07383d1c5f
---
Edge TTS (zh-TW-YunJheNeural) 產生的 MP3 和動畫字幕混音時，adelay 需要提前 **600ms** 才能讓語音和字幕感知同步。

**Why:** TTS MP3 有 ~200-350ms 前導靜音，加上 ffmpeg amix/AAC 編碼的容器偏移，累計約 600ms。即使用 silencedetect 裁掉前導靜音，仍需 ~600ms 偏移。第一句（adelay=0）不受影響，第二句開始才有感知延遲。

**How to apply:** 做 TTS 配音影片時，adelay = subtitle_start_ms - 600。第一句保持 0（不能為負）。用 `voice/trimmed/` 裁剪過靜音的檔案效果更穩定。
