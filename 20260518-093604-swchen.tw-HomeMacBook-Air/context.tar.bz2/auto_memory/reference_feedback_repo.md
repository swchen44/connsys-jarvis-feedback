---
name: feedback-repo-url
description: GitHub feedback repo URL for framework-feedback-report-flow skill
type: reference
originSessionId: 151b2638-d0a6-46cb-b2d8-2155e1a1ac80
---
Feedback Loop 系統的 GitHub feedback repo：
- URL: https://github.com/swchen44/connsys-jarvis-feedback
- 用途：使用者透過 `/framework-feedback-report-flow` 上傳 feedback bundle
- 環境變數：`JARVIS_FEEDBACK_REPO=https://github.com/swchen44/connsys-jarvis-feedback.git`
