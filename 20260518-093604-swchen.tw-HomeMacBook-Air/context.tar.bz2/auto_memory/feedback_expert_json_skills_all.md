---
name: expert-json-skills-all
description: framework-base-expert 的 expert.json skills 欄位使用 ["ALL"] 而非逐一列出
type: feedback
originSessionId: afcedc3c-2f80-4666-94ee-b8d3fcb9e10a
---
framework-base-expert 的 expert.json 中 `internal.skills` 使用 `["ALL"]` 自動包含所有 skills，不要逐一列出 skill 名稱。

**Why:** 每次新增 skill 都要改 expert.json 很煩，用 ALL 就只需要把 skill 放到 skills/ 目錄即可。

**How to apply:** 建立新 skill 時不需要修改 framework-base-expert 的 expert.json，直接建立 skill 目錄和檔案即可。
