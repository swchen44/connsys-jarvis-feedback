---
name: UI verify via Browser + self-check first
description: 任何 dashboard / web UI 改動的驗收必須用 claude-in-chrome MCP 跑具體 browser test case，且 Claude 自己先全綠才能請 user 看
type: feedback
originSessionId: d0ee26d0-05f9-450f-806f-056fb61883f2
---
任何 dashboard 或 web UI 變動，**驗收階段必須**：

1. **寫具體 browser test case**（不是抽象的「打開看看」），每個 case 有：ID、描述、動作（JS selector / chip API / click）、期望（exact text / count / order）
2. **用 `mcp__claude-in-chrome__*` 工具自己先跑過全部 case**（tabs_create_mcp 載入 file:// 或 http://，javascript_tool 抓 DOM，read_page snapshot）
3. **全綠才告訴 user 來看**；任一 case FAIL 就回去修，不要硬報 pass
4. Browser cases 要 **append 進專案既有的 `e2e-browser-checks.md`**（如果存在），不要另開散落

**Why:** user 不希望變成 reviewer 還要自己摸索 UI 有沒有壞；要 Claude 把 manual QA 做完。「綠燈 unit test ≠ 真 UI 行得通」 — 同 mock vs real-world gap 的精神。

**How to apply:** dashboard / 任何 HTML / JS / template 改動的 plan，verification 段一定包含「Browser test cases (BT-NN) + 我自己跑過確認」這條，不能只列 `python -m unittest`。
