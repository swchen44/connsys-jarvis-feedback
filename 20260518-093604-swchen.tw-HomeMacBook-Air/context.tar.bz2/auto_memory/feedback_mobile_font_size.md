---
name: Mobile video font sizing
description: 1920x1080 動畫影片在 6.5 吋手機上觀看時的字體大小規範
type: feedback
originSessionId: d99bf67c-1aff-4667-8f66-0c07383d1c5f
---
1920x1080 canvas 在 6.5 吋手機上橫向觀看縮放比例約 0.224x，預設字體太小。

**Why:** 使用者主要用 6.5 吋手機觀看影片，標準 web 字體大小（12-22px）縮放後在手機上幾乎無法閱讀。經過多輪調整確認的最終數值。

**How to apply:** 製作 1920x1080 動畫影片時，使用以下最低字體大小：

| 元素 | canvas px | 手機上約 |
|---|---|---|
| Hero 標題 | 130px | 29px |
| 段落標題 | 72px | 16px |
| Case study 標題 | 52px | 12px |
| 卡片標題/正文 | 46px | 10px |
| 標籤/Prompt 文字 | 40px | 9px |
| Code/Mono 標籤 | 36px（最小值）| 8px |
| 字幕條 | 54px | 12px |
| Dashboard 數字 | 80px | 18px |

同時減少 padding（60-80px 取代 100-140px）避免大量留白。
