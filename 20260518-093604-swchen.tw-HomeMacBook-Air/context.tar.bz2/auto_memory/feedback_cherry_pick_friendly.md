---
name: Cherry-pick friendly commits
description: 此 repo 在其他 git repo 開發，所有改動必須方便 cherry-pick，註解清楚且分層次
type: feedback
originSessionId: 65fbe13f-a741-44c4-9c31-131c1255deb9
---
所有程式碼改動必須可以讓對方容易 cherry-pick，因此註解要清楚且分層次。

**Why:** 此 repo (connsys-jarvis) 已在其他 Git repo 開始開發，merge 時需要解 conflict，清晰的 commit 分層和註解讓 cherry-pick 順利。

**How to apply:** 每個功能改動分開 commit，commit message 詳述改動目的和範圍；程式碼內註解分層（模組級 → 函數級 → 行內），讓 reviewer 一眼看出每段的職責邊界。
