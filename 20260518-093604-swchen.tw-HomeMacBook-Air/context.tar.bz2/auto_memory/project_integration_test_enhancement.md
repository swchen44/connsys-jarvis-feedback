---
name: Integration Test Enhancement Plan
description: tests/claudecode 強化計畫 — report 格式重構 + CLI 參數 + upload + KPI 整合（Phase 4e 後續）
type: project
originSessionId: 65fbe13f-a741-44c4-9c31-131c1255deb9
---
tests/claudecode integration test 框架強化計畫，分 4 個 commit：

1. **Report.md 格式重構**：Summary Table（含 K1-K5, S1-S6, Behavior Phases, NL detail, Cost breakdown, Efficiency）+ 完整 Command（不省略）+ Expert 安裝指令 + 欄位定義對照表
2. **CLI 參數強化**：--experts 多 expert、--cases 跨 expert 挑選、--skip-eval 跳過 NL/Judge、--session-analysis {none,local,ai} 取代舊 --analysis-mode、--upload 上傳
3. **Upload Report**：自建打包上傳（共用 CONNSYS_JARVIS_FEEDBACK_REPO/GERRIT 環境變數），per-test-case comment
4. **文件更新**：README.md + design.md

**Why:** report 缺少 KPI 和統計大表讓使用者難以一目了然；CLI 缺少跳過 eval 和多 expert 的靈活度拖慢開發；沒有 upload 讓 regression cron 結果無法自動追蹤。

**How to apply:** Plan 在 `/Users/swchen.tw/.claude/plans/tender-yawning-whale.md`，包含完整 report.md 目標格式、CLI 參數表、環境變數、實作順序。下次直接從 Commit 1 開始實作。

**Status:** Phase 4e（KPI config）已完成。並行執行 + batch eval 已完成（27min→10.5min）。本計畫尚未開始實作。
