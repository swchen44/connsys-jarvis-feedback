---
name: 改 code 後一定要同步改 design / requirements / case study
description: 任何功能改動完成後，design.md / requirements.md / 既有 e2e checks / case study 全部要同步更新
type: feedback
originSessionId: d0ee26d0-05f9-450f-806f-056fb61883f2
---
完成 code change 後，**收尾必須**包含：

1. 對應的 `docs/design.md` — 資料 shape、flow diagram、設計決策段
2. 對應的 `docs/requirements.md` — FR-NN 條目，加新 FR 或修現有
3. 既有的 e2e/regression checks doc（如 `e2e-browser-checks.md`、`KPI reference`）— append 新 case
4. **Case study 文件**寫在 `tests/claudecode/doc/case_study_<topic>/<topic>_YYYYMMDD.md`，包含動機、改動範圍對照表、設計決策、驗證結果、gotchas、下一步
5. README 如果有列舉這個 feature 旁邊的 sibling list，順手更新

**Why:** Cherry-pick friendly + 未來 reviewer / 未來的我都要看得到完整脈絡。code 改沒寫 doc，下次有人 review 會用舊敘述當 source-of-truth → 衝突。

**How to apply:** 寫 plan 時 verification 段下面一定有專屬「Step N — 更新 design / requirements / e2e checks / case study」step，**不要當 optional**；明確列要動的 doc 路徑。estimate 時間包含這個 step（通常 30-60 min）。
