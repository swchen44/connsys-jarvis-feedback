---
name: no-emoji
description: User does not want emojis in code output, CLI output, or documentation files
type: feedback
originSessionId: 65fbe13f-a741-44c4-9c31-131c1255deb9
---
Do not use emojis in code, CLI output, or documentation. Use text markers like `[OK]`, `[FAIL]`, `[--]`, `[WARN]` instead.

**Why:** User explicitly requested "不要使用emoji" when seeing emoji in CLI doctor output design.

**How to apply:** Any CLI output, report formatting, or documentation should use plain ASCII text indicators rather than emoji characters.
