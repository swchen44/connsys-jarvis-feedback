---
name: commit-message-detail-for-cherry-pick
description: Commit messages must be very detailed for cross-repo cherry-pick and LLM-assisted merge conflict resolution
type: feedback
originSessionId: 151b2638-d0a6-46cb-b2d8-2155e1a1ac80
---
Commit messages 要寫得非常清楚詳細，因為這份 code 在其他 Git repo 也有開發，需要 cherry-pick。
當發生 merge conflict 時，大型模型會用 commit message 來理解意圖並做 merge。

**Why:** 多 repo 並行開發，cherry-pick 是常見操作。衝突時 LLM 需要從 commit message 理解改動的完整意圖。

**How to apply:** 每個 commit message 要包含：
- 改了哪些函式/區段
- 為什麼改（問題描述）
- 怎麼改（實作方式摘要）
- 影響範圍（哪些行為改變、哪些不變）
- 如果有新增函式，說明其用途和呼叫者
